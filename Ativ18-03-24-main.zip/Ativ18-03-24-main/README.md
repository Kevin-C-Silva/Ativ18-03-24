# Ativ18-03-24
Esta atividade foi realizada com o propósito de conhecer mais sobre o GitHub e o GitBash.

![Git - Downloading Package e mais 3 páginas —  InPrivate  — Microsoft​ Edge 18_03_2024 11_07_32](https://github.com/Kevin-C-Silva/Ativ18-03-24/assets/160874548/5b394fe9-cc53-4d36-860e-1ed5f5cdb55a)
![Git - Downloading Package e mais 3 páginas —  InPrivate  — Microsoft​ Edge 18_03_2024 11_08_27](https://github.com/Kevin-C-Silva/Ativ18-03-24/assets/160874548/65e3cff7-efd7-40ac-b2be-e3a080f0fc34)

Nas imagens acima criei o repositório no GitHub




